<?php
session_start();
?>
<?php
$randomNum = mt_rand(1000, 9999);
?>
<!DOCTYPE html>
<html>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha2/css/bootstrap.min.css" integrity="sha384-DhY6onE6f3zzKbjUPRc2hOzGAdEf4/Dz+WJwBvEYL/lkkIsI3ihufq9hk9K4lVoK" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha2/js/bootstrap.bundle.min.js" integrity="sha384-BOsAfwzjNJHrJ8cZidOg56tcQWfp6y72vEJ8xQ9w6Quywb24iOsW913URv1IS4GD" crossorigin="anonymous">
    </script>
<head>
    <meta charset='utf-8'>
    <style>
        table.table2 {
            border-collapse: separate;
            border-spacing: 1px;
            text-align: left;
            line-height: 1.5;
            border-top: 1px solid #ccc;
            margin: 20px 10px;
        }

        table.table2 tr {
            width: 50px;
            padding: 10px;
            font-weight: bold;
            vertical-align: top;
            border-bottom: 1px solid #ccc;
        }

        table.table2 td {
            width: 100px;
            padding: 10px;
            vertical-align: top;
            border-bottom: 1px solid #ccc;
        }
    </style>
    <script>
        function check_input() {
            if (!document.board_form.password.value) {
                alert("비밀번호를 입력하세요!");
                document.board_form.password.focus();
                return;
            }
            if (!document.board_form.subject.value) {
                alert("제목을 입력하세요!");
                document.board_form.subject.focus();
                return;
            }
            if (!document.board_form.content.value) {
                alert("내용을 입력하세요!");
                document.board_form.content.focus();
                return;
            }
            if (!document.board_form.secret_code.value) {
                alert("보안코드를 입력하세요!");
                document.board_form.secret_code.focus();
                return;
            }
            document.board_form.submit();
        }
    </script>
</head>

<body style="background-color:aliceblue">
    <form enctype='multipart/form-data' action='insert_table.php' method='post'>
        <table style="padding-top:50px" align=center width=auto border=0 cellpadding=2>
            <tr>
                <td style="height:40; float:center; background-color:white">
                    <p style="font-size:25px; text-align:center; color:black; margin-top:15px; margin-bottom:15px">
                        <b>[ 게시글 작성하기 ]</b>
                    </p>
                </td>
            </tr>
            <tr>
                <td bgcolor=white>
                        <table class="table2">
                            <tr>
                                <td>아이디</td>
                                <td>
                                    <?php if (isset($_SESSION['mb_id'])) { echo "{$_SESSION['mb_id']}"; }?>
                                </td>
                                </tr>
                            <tr>
                                <td>비밀번호</td>
                                <td><input type="password" name="password" size=15></td>
                            </tr>
                            <tr>
                                <td>제목</td>
                                <td><input type="text" name="subject" size=50>
                            </td>
                            </tr>
                            <tr>
                                <td>내용</td>
                                <td><textarea name="content" cols=75 rows=15></textarea></td>
                            </tr>    
	                        <tr>
                                <td>첨부파일</td>    
                                <td><input type='file' name="file[]"  multiple /></td>
                              <tr>
                                <td><?php echo "보안코드 : $randomNum"?></td>
                                <td><input type="text" name="secret_code" id="secret_code" 
                                    placeholder="보안코드를 입력 해주세요."></td>
                            </tr>
                        </table>    
                    <center>
                        <button type="submit" class="btn btn-primary mb-3" onclick="check_input()" location.href="'./board_list.php'">완료</button>
                        <button type="button" class="btn btn-primary mb-3" onclick="location.href='board_list.php'">목록</button>
                    </center>
                </td>
            </tr>
        </table>
    </form>
</body>

</html>