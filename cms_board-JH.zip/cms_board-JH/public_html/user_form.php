<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha2/css/bootstrap.min.css" integrity="sha384-DhY6onE6f3zzKbjUPRc2hOzGAdEf4/Dz+WJwBvEYL/lkkIsI3ihufq9hk9K4lVoK" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha2/js/bootstrap.bundle.min.js" integrity="sha384-BOsAfwzjNJHrJ8cZidOg56tcQWfp6y72vEJ8xQ9w6Quywb24iOsW913URv1IS4GD" crossorigin="anonymous">
    </script>
<body style="background-color:aliceblue">
<?php
    $connect = include "dbcon.php";
    session_start();
    $sql = "select * from member order by mb_no desc";
    $num = ['mb_no'];
    $result = $mysqli->query($sql) or die($mysqli->error);
    $rows = mysqli_fetch_assoc($result);
?>
<form action="userstatus.php" method="GET">
<table class="view_table" align=center>
<tr>
    <tr><td class="view_id"><a href="user_form.php?mb_no=<?=$num?>"></tr>
    <tr><td class="view_id">아이디 : <?php echo $rows['mb_id']?></td></tr></br></br></br></br></br></br></br></br></br>
    <tr><td>-----------------------------</td></tr>
    <tr><td class="view_id">이름 : <?php echo $rows['mb_name']?></td></tr>
    <tr><td>-----------------------------</td></tr>
    <tr><td class="view_id">전화번호 : <?php echo $rows['mb_hp']?></td></tr>
    <tr><td>-----------------------------</td></tr>
    <tr><td class="view_id">별명 : <?php echo $rows['mb_nick']?></td></tr>
    <tr><td>-----------------------------</td></tr>
    <tr><td class="view_id">주소 : <?php echo $rows['mb_addr1']?></td></tr>
</tr>
</tr>
</form>
</table>
</body>