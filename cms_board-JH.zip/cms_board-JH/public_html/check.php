<?php
   include "dbcon.php";
   $uid = $_GET["userid"];

   $sql = "select * from member where mb_id='".$uid."'";
    $result=$mysqli->query($sql) ;

   $member = $result -> fetch_array();
   if($member==0){
?>
         <div style=' text-align:center; color:blue;"';><?php echo $uid; ?>는 사용가능한 아이디입니다.</div>
<?php 
      }else{
?>
         <div style='text-align:center; color:red;'><?php echo $uid; ?>중복된아이디입니다.<div>
<?php
      }
?>
      <button style='text-align:center' value="닫기" onclick="window.close()">닫기</button>