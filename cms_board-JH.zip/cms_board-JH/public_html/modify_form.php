<?php
$randomNum = mt_rand(1000, 9999);

$connect = mysqli_connect('203.228.23.7', 'naturei20', 'Ni0801!!', 'naturei20') or die("connect fail");
    session_start();
    $query = "select mb_id, wr_name, wr_subject, wr_content, wr_file from board where wr_id";   
    $result = $connect->query($query);
    $rows = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <style>
        table.table2 {
            border-collapse: separate;
            border-spacing: 1px;
            text-align: left;
            line-height: 1.5;
            border-top: 1px solid #ccc;
            margin: 20px 10px;
        }

        table.table2 tr {
            width: 50px;
            padding: 10px;
            font-weight: bold;
            vertical-align: top;
            border-bottom: 1px solid #ccc;
        }

        table.table2 td {
            width: 100px;
            padding: 10px;
            vertical-align: top;
            border-bottom: 1px solid #ccc;
        }
    </style>
    <script>
        function check_input() {
            if (!document.board_form.id.value) {
                alert("아이디를 입력하세요!");
                document.board_form.id.focus();
                return;
            }
            if (!document.board_form.name.value) {
                alert("이름을 입력하세요!");
                document.board_form.name.focus();
                return;
            }
            if (!document.board_form.subject.value) {
                alert("제목을 입력하세요!");
                document.board_form.subject.focus();
                return;
            }
            if (!document.board_form.content.value) {
                alert("내용을 입력하세요!");
                document.board_form.content.focus();
                return;
            }
            document.board_form.submit();
        }
    </script>
</head>

<body style="background-color:aliceblue">
    <form name="board_form" method="post" enctype="multipart/fome-data">
        <table style="padding-top:50px" align=center width=auto border=0 cellpadding=2>
            <tr>
                <td style="height:40; float:center; background-color:white">
                    <p style="font-size:25px; text-align:center; color:black; margin-top:15px; margin-bottom:15px">
                        <b>[ 게시글 수정하기 ]</b>
                    </p>
                </td>
            </tr>
            <tr>
                <td bgcolor=white>
                        <table class="table2">
                            <tr><?php echo $rows['mb_id']?>
                                <td>아이디</td>
                                <td></td>
                            </tr>
                            <tr>
                                <td>작성자</td>
                                <td><?php echo $rows['wr_name']?></td>
                            </tr>
                            <tr>
                                <td>제목</td>
                                <td><?php if (isset($_SESSION['wr_subject'])) { echo "{$_SESSION['wr_subject']}"; }?></td>
                            </tr>
                            <tr>
                                <td>내용</td>
                                <td><textarea cols=75 rows=15 <?php if (isset($_SESSION['mb_id'])) { echo "{$_SESSION['mb_id']}"; }?>></textarea> </td>
                            </tr></form>
                            <form action="board_view.php" method="post" enctype="multipart/form-data">
                            <tr>
                            <div id="in_file">
                            <td>첨부파일</td>    
                            <td><input type="file" value="1" name="file"></td>
                            </div>
                        </tr>
                            </table>
    
    <center>
        <button><a href="modify_ok.php?wr_id=<?=$num?>">완료</button>
    </center>
    <center>
        <button type="button" onclick="location.href='board_list.php'">목록</button>
    </center>
    </td>
    </tr>
    </table>
    </form>
</body>

</html>
</html>