<?php 
include "dbcon.php";
?>
<?php
$num = $_GET['wr_id'];
$query = "delete from board where wr_id=$num";
mysqli_query($mysqli,$query);
?>
<script type="text/javascript">alert("삭제되었습니다.");</script>
<meta http-equiv="refresh" content="0 url=/cms_board-master/JH/public_html/board_list.php" />