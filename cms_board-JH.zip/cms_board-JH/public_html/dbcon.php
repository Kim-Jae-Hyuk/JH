<?php
$hostname = "203.228.23.7";
$username = "naturei20";
$password = "Ni0801!!";
$dbname = "naturei20";

$mysqli = new mysqli($hostname,$username, $password, $dbname);
if ($mysqli->connect_error) {
    die('Connect Error: '.$mysqli->connect_error);
}
?>