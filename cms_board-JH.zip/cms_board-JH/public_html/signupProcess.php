<?php
$conn = include "dbcon.php";
$hashedPassword = password_hash($_POST['mb_password'], PASSWORD_DEFAULT);
echo $hashedPassword;

$sql = "
    INSERT INTO member
    (mb_id, mb_password, mb_name, mb_email, mb_hp, mb_nick, mb_addr1) VALUES 
    ('{$_POST['userid']}', '{$hashedPassword}', '{$_POST['mb_name']}', 
     '{$_POST['mb_email']}', '{$_POST['mb_hp']}', '{$_POST['mb_nick']}', '{$_POST['mb_addr1']}')";
echo $sql;
$result =$mysqli->query($sql);

if ($result === false) {
    echo "저장에 문제가 생겼습니다. 관리자에게 문의해주세요.";
    echo mysqli_error($conn);
} else {
?>
    <script>
        alert("회원가입이 완료되었습니다");
        location.href = "index.php";
    </script>
<?php
}
?>