<?php
$conn = include "dbcon.php";
$id = $_POST['mb_id'];
$password = $_POST['mb_password'];

$sql = "SELECT * FROM member WHERE mb_id ='{$id}'";
$result = $mysqli->query($sql);

$row = mysqli_fetch_array($result);
$hashedPassword = $row['mb_password'];
$row['mb_id'];

foreach($row as $key => $r){
    echo "{$key} : {$r} <br>";
}
$passwordResult = password_verify($password, $hashedPassword);
if ($passwordResult === true) {
    session_start();
    $_SESSION['mb_id'] = $row['mb_id'];
    print_r($_SESSION);
    echo $_SESSION['mb_id'];
    
?>
    <script>
       alert("환영합니다.")
        location.href = "index.php";
    </script>
<?php
} else {
?>
    <script>
        alert("아이디 또는 비밀번호를 확인하세요.");history.back();;
    </script>
<?php
}
?>