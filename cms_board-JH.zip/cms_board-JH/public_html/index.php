<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha2/css/bootstrap.min.css" integrity="sha384-DhY6onE6f3zzKbjUPRc2hOzGAdEf4/Dz+WJwBvEYL/lkkIsI3ihufq9hk9K4lVoK" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha2/js/bootstrap.bundle.min.js" integrity="sha384-BOsAfwzjNJHrJ8cZidOg56tcQWfp6y72vEJ8xQ9w6Quywb24iOsW913URv1IS4GD" crossorigin="anonymous"></script>
</head>

<body style="background-color:aliceblue">
<table style="text-align:center; ">
  <tr>
    <td><img src="./files/cat.jpg" style=" display:block;" width="510px" height="550px"/><span>안녕하세요일</span></td>
    <td><img  src="./files/cat2.jpg" style=" display:block;" width="510px" height="550px"/><span>안녕하세요이</span></td>
    <td><img  src="./files/cat3.jpg" style=" display:block;" width="510px" height="550px"/><span>안녕하세요삼</span></td>
  <tr>
</table>

    <ul class="nav justify-content-end">
        <center>
        <h2><?php
            if (isset($_SESSION['mb_id'])) {
                echo "{$_SESSION['mb_id']}님 환영합니다!";

            ?></h2>
        <table>
            <h2>
                <td><button class="btn btn-primary mb-3" onclick="location.href='./userstatus.php'">회원 관리</button></td>
                <td><button class="btn btn-primary mb-3" onclick="location.href='./board_list.php'">게시판</button></td>
                <td><button class="btn btn-primary mb-3" onclick="location.href='./board_form.php'">글쓰기</button></td>
                <td><button class="btn btn-primary mb-3" onclick="logout()">로그아웃</button></td>
            </h2>
        <?php
            } else {
        ?>
                <h2 class="nav-item">
                    <td><button a class="btn btn-primary mb-3" aria-current="page" onclick="location.href='./signup.php'">회원가입</button></td>
                    <td><button class="btn btn-primary mb-3" onclick="location.href='./login.php'">로그인</button></td>
                    <td><button class="btn btn-primary mb-3" onclick="location.href='./board_list.php'">게시판</button></td>
                    
                </h2>
        <?php
            }
        ?>
        </center>
        </table>
    </ul>
    <script>
        function logout() {
            console.log("logout");
            const data = confirm("로그아웃 하시겠습니까?");
            if (data) {
                location.href = "logoutProcess.php";
            }

        }
    </script>
</body>

</html>