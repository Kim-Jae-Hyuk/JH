<?php
session_start();

?>
<!DOCTYPE html>
<html>
<head> 
<meta charset="utf-8">
<title></title>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha2/css/bootstrap.min.css" integrity="sha384-DhY6onE6f3zzKbjUPRc2hOzGAdEf4/Dz+WJwBvEYL/lkkIsI3ihufq9hk9K4lVoK" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha2/js/bootstrap.bundle.min.js" integrity="sha384-BOsAfwzjNJHrJ8cZidOg56tcQWfp6y72vEJ8xQ9w6Quywb24iOsW913URv1IS4GD" crossorigin="anonymous">
    </script>
<script>
	function register_link() {
		location.href = "register_form.php";
	}
	function delete_link() {
		location.href = "delete_form.php";
	}
</script>
</head>
<body> 
<ul class="nav justify-content-end">
        <?php
        if (isset($_SESSION['userId'])) {
            echo "{$_SESSION['userId']}님 환영합니다  ";
        ?>
            <li class="nav-item d-flex align-items-center" onclick="logout()">로그아웃</li>
        <?php
        } else {
        ?>
            <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="signup.php">회원가입 </a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="login.php">로그인</a>
            </li>

        <?php
        }
        ?>
    </ul>
    <script>
        function logout() {
            console.log("hello");
            const data = confirm("로그아웃 하시겠습니까?");
            if (data) {
                location.href = "logout.php";
            }

        }
    </script>
<section>
   	<div id="board_box">
	    <ul id="board_list">
				<li>
					<span class="col1">번호</span>
					<span class="col2">아이디</span>
					<span class="col3">이름</span>
					<span class="col4">연락처</span>
					<span class="col5">회원구분</span>
					<!-- <span class="col6">로그인 기록</span> -->
					<span class="col7">관리</span>
				</li>
<?php
	if (isset($_GET["page"]))
		$page = $_GET["page"];
	else
		$page = 1;

	$connect = include "dbcon.php";
	$sql = "select * from member order by mb_no desc";
	$result = $mysqli->query($sql) or die($mysqli->error);
	$total_record = mysqli_num_rows($result) ; // 전체 글 수

	$scale = 15;

	// 전체 페이지 수($total_page) 계산 
	if ($total_record % $scale == 0)     
		$total_page = floor($total_record/$scale);      
	else
		$total_page = floor($total_record/$scale) + 1; 
 
	// 표시할 페이지($page)에 따라 $start 계산  
	$start = ($page - 1) * $scale;      
	$number = $total_record - $start;
   for ($i=$start; $i<$start+$scale && $i < $total_record; $i++)
   {
      mysqli_data_seek($result, $i);
      // 가져올 레코드로 위치(포인터) 이동
      $row = mysqli_fetch_array($result);
      // 하나의 레코드 가져오기
	  $num         = $row["mb_no"];
	  $id        = $row["mb_id"];
      $name  = $row["mb_name"];
	  $phone         = $row["mb_hp"];
	  $level        = $row["mb_level"];
      $today_login  = $row["mb_today_login"];
?>
				<li>
					<span class="col1"><?=$num?></span>
					<!-- <span class="col2"><a href="userstatus.php?num=<?=$num?>&page=<?=$page?>"><?=$subject?></a></span> -->
					<span class="col2"><?=$id?></span>
					<span class="col3"><?=$name?></span>
					<span class="col4"><?=$phone?></span>
					<span class="col5"><?php 
					if($level == 1) {echo "사용자";}
					if($level == 2) {echo "관리자";}
					?></span>
					<!-- <span class="col6"><?=$today_login?></span> -->
					<span class="col7">
					<button type="button" class="btn btn-primary mb-3" onclick="location.href='user_form.php?mb_no=<?= $num ?>'">보기</button>
					<button type="button" class="btn btn-primary mb-3" >수정</button>
					<button type="button" class="btn btn-primary mb-3" onclick="location.href='delete_form.php?mb_no=<?=$num?>'" onclick="return confirm('삭제하시겠습니까?')" >삭제</button>
				</span>
				</li>	
<?php
   	   $number--;
   }
   $result = $mysqli->query($sql) or die($mysqli->error);

?>
	    	</ul>
			<ul id="page_num"> 	
<?php
	if ($total_page>=2 && $page >= 2)	
	{
		$new_page = $page-1;
		echo "<li><a href='userstatus.php?page=$new_page'>◀ 이전</a> </li>";
	}		
	else 
		echo "<li>&nbsp;</li>";

   	// 게시판 목록 하단에 페이지 링크 번호 출력
   	for ($i=1; $i<=$total_page; $i++)
   	{
		if ($page == $i)     // 현재 페이지 번호 링크 안함
		{
			echo "<li><b> $i </b></li>";
		}
		else
		{
			echo "<li><a href='userstatus.php?page=$i'> $i </a><li>";
		}
   	}
   	if ($total_page>=2 && $page != $total_page)		
   	{
		$new_page = $page+1;	
		echo "<li> <a href='userstatus.php?page=$new_page'>다음 ▶</a> </li>";
	}
	else 
		echo "<li>&nbsp;</li>";
?>
            </select>
</section>
<form action="search_result.php" method="get">
<input type="text" name="search" size="40" required="required">
<button class="btn btn-primary">검색</button>
</form>
</body>
</html>
