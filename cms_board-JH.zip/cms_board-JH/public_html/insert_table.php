<?php
include "dbcon.php";

date_default_timezone_set('Asia/Seoul');
$time = date("Y-m-d H:i:s");
$id = $_POST["id"];
$password = $_POST["password"];
$name = $_POST["name"];
$subject = $_POST["subject"];
$content = $_POST["content"];
    
$photo = $_FILES['file'];

$uploadDir = "./files/";
$fileName = $photo['name'];
$tmpName = $photo['tmp_name'];
$_SESSION['mb_id'];
$fileNames = array();

for($i=0; $i<count($fileName); $i++){
   move_uploaded_file($tmpName[$i], $uploadDir.$fileName[$i]);
   array_push($fileNames, $fileName[$i]);
   $arrayString = implode(",", $fileNames);
}

$status = 1;

$sql = "insert into board(mb_id,wr_password,wr_name,wr_subject,wr_content,wr_1, wr_datetime, wr_last) values 
('" . $id . "','" . $password . "','" . $name . "','" . $subject . "',
'" . $content . "','" . $arrayString . "','" . $time . "','" . $time . "')";

$result = $mysqli->query($sql) or die($mysqli->error);

if ($result) {
    echo "<script>alert('게시글이 등록 되었습니다.');location.href='board_list.php';</script>";
    exit;
} else {
    echo "<script>alert('글등록에 실패했습니다.');history.back();</script>";
    exit;
}
?>