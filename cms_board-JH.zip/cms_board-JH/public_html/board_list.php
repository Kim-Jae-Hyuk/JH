<?php
    include "dbcon.php";
?>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha2/css/bootstrap.min.css" integrity="sha384-DhY6onE6f3zzKbjUPRc2hOzGAdEf4/Dz+WJwBvEYL/lkkIsI3ihufq9hk9K4lVoK" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha2/js/bootstrap.bundle.min.js" integrity="sha384-BOsAfwzjNJHrJ8cZidOg56tcQWfp6y72vEJ8xQ9w6Quywb24iOsW913URv1IS4GD" crossorigin="anonymous">
    </script>

<!DOCTYPE html>

<html>

<head>
    <meta charset="utf-8">
</head>
<style>
    table {
        border-top: 1px solid #444444;
        border-collapse: collapse;
    }

    tr {
        border-bottom: 1px solid #444444;
        padding: 10px;
    }

    td {
        border-bottom: 1px solid #efefef;
        padding: 10px;
    }

    table .even {
        background: #efefef;
    }

    .text {
        text-align: center;
        padding-top: 20px;
        color: #000000
    }

    .text:hover {
        text-decoration: underline;
    }

    a:link {
        color: #57A0EE;
        text-decoration: none;
    }

    a:hover {
        text-decoration: underline;
    }
</style>

<body style="background-color:aliceblue">
    <?php
    $connect = mysqli_connect('203.228.23.7', 'naturei20', 'Ni0801!!', 'naturei20') or die("connect fail");
    $query = "select * from board order by wr_id desc";
    $result = $connect->query($query);
    $total = mysqli_num_rows($result);

    ?>
    <h1 align=center>[ 게시판 ]</h1>
    <table align=center>
        <thead align="center">
            <tr>
                <td width="80" align="center">[ 번호 ]</td>
                <td width="400" align="center">[ 제목 ]</td>
                <td width="150" align="center">[ 아이디 ]</td>
                <td width="100" align="center">[ 작성자 ]</td>
                <td width="200" align="center">[ 날짜 ]</td>
            </tr>
        </thead>
        <tbody>
            <?php
            while ($rows = mysqli_fetch_assoc($result)) {
                if ($total % 2 == 0) {
            ?> <tr class="evevn">
                    <?php   } else {
                    ?>
                    <tr>
                    <?php } ?>
                    <td width="50" align="center"><?php echo $total ?></td>
                    <td width="400" align="center">
                    <a href="board_view.php?wr_id=<?php echo $rows['wr_id'] ?>">
                    <?php echo $rows['wr_subject'] ?></a>
                    </td>
                    <td width="150" align="center"><?php echo $rows['mb_id'] ?></td>
                    <td width="100" align="center"><?php echo $rows['wr_name'] ?></td>
                    <td width="200" align="center"><?php echo $rows['wr_datetime'] ?></td>
                    </tr>
                <?php
                $total --;
            }
                ?>
        </tbody>
    </table>
    <div class=text>
        <center>
        <table>
        <td><button class="btn btn-primary mb-3" onclick="location.href='./board_form.php'">글쓰기</font></button></td>
        <td><button onclick="location.href='index.php'" class="btn btn-primary mb-3">홈</td>
        </table>
        </center>
    </div>
</body>
</html>