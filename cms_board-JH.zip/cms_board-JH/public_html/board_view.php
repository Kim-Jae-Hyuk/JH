<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha2/css/bootstrap.min.css" integrity="sha384-DhY6onE6f3zzKbjUPRc2hOzGAdEf4/Dz+WJwBvEYL/lkkIsI3ihufq9hk9K4lVoK" crossorigin="anonymous">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.0.0-alpha2/js/bootstrap.bundle.min.js" integrity="sha384-BOsAfwzjNJHrJ8cZidOg56tcQWfp6y72vEJ8xQ9w6Quywb24iOsW913URv1IS4GD" crossorigin="anonymous">
    </script>
<body style="background-color:aliceblue">
<?php
    $connect = mysqli_connect('203.228.23.7', 'naturei20', 'Ni0801!!', 'naturei20') or die("connect fail");
    $num = $_GET['wr_id'];
    session_start();
    $query = "select mb_id, wr_name, wr_subject, wr_content, wr_file, wr_1 from board where wr_id =$num";   
    $result = $connect->query($query);
    $rows = mysqli_fetch_assoc($result);
?>
<form action="board_list.php" method="POST">
<table class="view_table" align=center>
<tr>
    <tr><td class="view_id"><h1><b>[ 게시글 ]</b></h1> </td></tr>
    <td class="view_id">아이디 : <?php echo $rows['mb_id']?></td>
    <td class="view_id">작성자 : <?php echo $rows['wr_name']?></td>

</tr>
<tr>   
    <td class="view_id">제목 : <?php echo $rows['wr_subject'] ?></td>
</tr>
<tr> 
   
    <td class="view_id">내용 : <?php echo $rows['wr_content']?></td>
</tr></form>
    <td class="view_id">첨부파일 : </td>
    <td>
    <?php 
        $uploadDir = "./files/";
        $photoArr = explode(",",$rows['wr_1']);
        for($i=0; $i<count($photoArr); $i++){ ?>
        <a href="./files/<?php echo $photoArr[$i]; ?>"download> <?php echo $photoArr[$i]; ?></a>
        <?php
        }
        ?>
</tr>
</form>
</table>
    </body>
<center>
    <td><button type="button" onclick="location.href='modify_form.php'" class="btn btn-primary mb-3">수정</button></td>
    <td><button onclick="location.href='board_list.php'" class="btn btn-primary mb-3">목록</button></td>
    <td><button onclick="location.href='delete.php?wr_id=<?=$num?>'" onclick="return confirm('삭제하시겠습니까?')" class="btn btn-primary mb-3">삭제</button></td>
</center>


