<?php 
  include "dbcon.php";
?>
<!doctype html>
<head>
<meta charset="UTF-8">
<title>게시판</title>
<link rel="stylesheet" type="text/css" href="/css/style.css" />
</head>
<body>
<div id="board_area"> 
<!-- 18.10.11 검색 추가 -->
<?php
 
  /* 검색 변수 */
  $catagory = $_GET['catgo'];
  $search_con = $_GET['search'];
?>
  <h1><?php echo $catagory; ?>에서 '<?php echo $search_con; ?>'검색결과</h1>
  <h4 style="margin-top:30px;"><a href="/">홈으로</a></h4>
    <table class="list-table">
      <thead>
          <tr>
              <th width="70">아이디</th>
                <th width="100">이름</th> 
                <th width="100">별명</th>
                <th width="120">전화번호</th>
                <th width="100">주소</th>
            </tr>
        </thead>
        <?php
          $sql2 = "select * from member where $catagory like '%$search_con%' order by mb_id desc";
          $result = $mysqli->query($sql2) or die($mysqli->error);
          while($result){
           
          
            if(strlen($title)>30)
              { 
              }
            $sql3 = "select * from member where mb_id='".$category['mb_id']."'";
            $result = $mysqli->query($sql3) or die($mysqli->error);
            $rep_count = mysqli_num_rows($result);
        ?>
          <?php
          }
          ?>