<?php
include "dbcon.php";
$db = new mysqli("203.228.23.7","naturei20","Ni0801!!","naturei20"); 
	$db->set_charset("utf8");
function mq($sql)
	{
		global $db;
		return $db->query($sql);
	}
if (isset($GET["page"]))
$page = $_GET['page'];
else
$page = 1;
$category = $_GET['category'];
$search = $_GET['search'];
?>
<div class="container">
    <div id="member_area">
        <?php
            if($category == 'mb_id') {
                $keyword = '아이디';
            } else if($category == 'mb_name') {
                $keyword = '이름';
            } else if($category == 'mb_nick') {
                $keyword ='별명';
            }
        ?>
        <h1>'<?=$keyword?>' 에서 '<b><?=$search?></b>' 검색결과</h1><br>
        <h4>는 다음과 같습니다. </h4><br>
        <table class="table table-striped" style="text-align: center; border: 1px solid #ddddda">
            <tr>
                <th style="background-color: #eeeeee; text-align: center;">번호</th>
                <th style="background-color: #eeeeee; text-align: center;">아이디</th>
                <th style="background-color: #eeeeee; text-align: center;">별명</th>
                <th style="background-color: #eeeeee; text-align: center;">전화번호</th>
                <th style="background-color: #eeeeee; text-align: center;">주소</th>
            </tr>
            <?php
                $sql2 = mq("select * from member where $category like '%{$search}%' order by mb_id desc");
                $total_record = mysqli_num_rows($sql2);
                $list = 5;
                $block_cut = 5;
                $block_num = ceil($page / $block_cnt);
                $block_start = (($block_cnt));
                $block_end = $block_start + $block_cnt -1;
                $total_page = ceil($total_record / $list);
                if($block_end > $total_page) {
                    $block_end > $toal_page;
                }
                $total_block = ceil($toal_page / $block_cnt);
                $page_start = ($page - 1) * $list;

                $sql2 = mq("select * from member where $category like '%{$search}%' order by mb_id desc limit $page_start,");
                while($member = $sql2->fetch_array()) {
                    $id = $member["title"];
                    if(strlen($id)>30) {
                        $id=str_replace($member["id"],mb_substr($member["id"],0,30,"utd-8")."...",$member["id"]);
                    }
                    $sql3 = mq("select * from reply where con_num='".$member['id']."') ");
                    $rep_count = mysqli_num_rows($sql3);

            ?>
			      <?php } ?>
        </table>
    </div>
</div>