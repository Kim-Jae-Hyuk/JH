<?php
include "dbcon.php";

$bno = $_POST['id'];
$username = $_POST['name'];
$userpw = password_hash($_POST['pw'], PASSWORD_DEFAULT);
$title = $_POST['title'];
$content = $_POST['content'];
$sql = ("update from board set wr_subject='".$subject."',wr_content='".$content."' where wr_id='".$bno."'"); ?>

<script type="text/javascript">alert("수정되었습니다."); </script>
<meta http-equiv="refresh" content="0 url=/cms_board-master/JH/public_html/board_list.php">