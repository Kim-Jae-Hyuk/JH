<?php
include "dbcon.php";

$conn = new PDO("mysql:host=$hostname;dbname=$dbname","$username","$password");
$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
if(isset($_GET['submit'])){
    $countfiles = count($_FILES['fileup']['name']);
    $query = "INSERT INTO wr_file (id, name) VALUES(?,?)";
    $statement = $conn->prepare($query);
    for($i=0;$i<$countfiles;$i++){
        $filename = $_FILES['fileup']['name'][$i];
        $target_file = 'upload/'.$file;
        move_uploaded_file($_FILES['fileup']['tmp_name'][$i],$target_file);
        $statement->execute(array($filename,$target_file));
        }
  }    

date_default_timezone_set('Asia/Seoul');
$time = date("Y-m-d H:i:s");
$num = $_GET["num"];
$id = $_GET["id"];
$password = $_GET["password"];
$name = $_GET["name"];
$subject = $_GET["subject"];
$content = $_GET["content"];
$file = $_GET["fileup"];


$status = 1; //status는 1이면 true, 0이면 false이다.

$sql = "insert into board(wr_id,mb_id,wr_password,wr_name,wr_subject,wr_content,wr_file, wr_datetime, wr_last) values 
('". $num. "','" . $id . "','" . $password . "','" . $name . "','" . $subject . "',
'" . $content . "','" . $file . "','" . $time . "','" . $time . "')";

$result = $mysqli->query($sql) or die($mysqli->error);

if ($result) {
    echo "<script>alert('게시글이 등록 되었습니다.');location.href='board_list.php';</script>";
    exit;
} else {
    echo "<script>alert('글등록에 실패했습니다.');history.back();</script>";
    exit;
}
?>
<form name="insert_table" method="GET" action="insert_table.php" action="board_view.php">
</form>
