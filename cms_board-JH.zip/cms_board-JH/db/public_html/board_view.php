<?php
    $connect = mysqli_connect('203.228.23.7', 'naturei20', 'Ni0801!!', 'naturei20') or die("connect fail");
    $num = $_GET['wr_id'];
    session_start();
    $query = "select mb_id, wr_name, wr_subject, wr_content, wr_file from board where wr_id =$num";   
    $result = $connect->query($query);
    $rows = mysqli_fetch_assoc($result);
?>

<table class="view_table" align=center>
<tr>
    <tr><td class="view_id"><h1><b>[ 게시글 ]</b></h1> </td></tr>
    <td class="view_id">아이디 : </td>
    <td class="view_id2"><?php echo $rows['mb_id']?></td>
    <td class="view_id">작성자 : </td>
    <td class="view_id2"><?php echo $rows['wr_name']?></td>
</tr>
<tr>   
    
    <td class="view_id">제목 : </td>
    <td class="view_id2"><?php echo $rows['wr_subject'] ?></td>
</tr>
<tr> 
   
    <td class="view_id">내용 : </td>
    <td class="view_id2"><?php echo $rows['wr_content']?></td>
    
</tr>
<tr>
    <td class="view_id">첨부파일 : </td>
    <td class="view_id2"><?php echo $rows['wr_file']?></td>
</tr>
</table>
<center>
    <td><button onclick="location.href='modify_form.php'">수정</button></td>
    <td><button onclick="location.href='board_list.php'">목록</button></td>
    <td><button><a href="delete.php?wr_id=<?=$num[0]?>" onclick="return confirm('삭제하시겠습니까?')">삭제</button></td>
</center>
