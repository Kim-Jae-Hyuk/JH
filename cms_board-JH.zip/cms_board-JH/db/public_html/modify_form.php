<!doctype html>

<head>
    <meta charset="UTF-8">
    <title>게시판</title>
    <link rel="stylesheet" href="/css/style.css" />
</head>

<body>
    <?php
    $connect = mysqli_connect('203.228.23.7', 'naturei20', 'Ni0801!!', 'naturei20') or die("connect fail");
    $query = "select * from board order by wr_id desc";
    $result = $connect->query($query);
    $total = mysqli_num_rows($result)

    ?>
    <div id="board_write">
        <center>
        <h1><a href="index.php">게시판</a></h1>
        <h4>글 수정하기</h4>
            <div id="write_area">
                <form action="modify_ok.php?idx=<?php echo $bno; ?>" method="post">
                    <div id="in_title">
                        <textarea name="subject" id="wr_subject" rows="1" cols="55" placeholder="제목" maxlength="100" required><?php echo $board['subject']; ?></textarea>
                    </div>
                    <div class="wi_line"></div>
                    <div id="in_name">
                        <textarea name="name" id="wr_name" rows="1" cols="55" placeholder="작성자" maxlength="100" required><?php echo $board['name']; ?></textarea>
                    </div>
                    <div class="wi_line"></div>
                    <div id="in_content">
                        <textarea name="content" id="wr_content" placeholder="내용" required><?php echo $board['content']; ?></textarea>
                    </div>
                    <div id="in_id">
                        <input type="id" name="id" id="mb_id" placeholder="비밀번호" required />
                    </div>
                    <div id="in_pw">
                        <input type="password" name="pw" id="wr_password" placeholder="비밀번호" required />
                    </div>
                    <div class="bt_se">
                        <button type="submit">글 작성</button>
                    </div>
        </center>
        </form>
    </div>
    </div>
</body>

</html>