<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>게시판 제작</title>
<div style="background-color:lightgrey; color:green; text-align:center">    
    <h1>
            <center>
            <a href="index.php">[ 게시판 ]</a>
            </center>
    </h1>
</head>

<header>
    <h3>
        <center>
        <table>
        <tr>    
            <td><button><a href="board_list.php">목록</a></button></td>
        </tr>
        <tr>
            <td><button><a href="board_form.php">글쓰기</a></button></td>
        </tr>
        </table>
        </center>
    </h3>
</header>

<body>
    <table>


    </table>
</body>
<footer>
    게시판을 만들어 보자~~~
</footer>
</div>
</body>

</html>