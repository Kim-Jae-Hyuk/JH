<?php
$randomNum = mt_rand(1000, 9999);
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset='utf-8'>
    <style>
        table.table2 {
            border-collapse: separate;
            border-spacing: 1px;
            text-align: left;
            line-height: 1.5;
            border-top: 1px solid #ccc;
            margin: 20px 10px;
        }

        table.table2 tr {
            width: 50px;
            padding: 10px;
            font-weight: bold;
            vertical-align: top;
            border-bottom: 1px solid #ccc;
        }

        table.table2 td {
            width: 100px;
            padding: 10px;
            vertical-align: top;
            border-bottom: 1px solid #ccc;
        }
    </style>
    <script>
        function check_input() {
            if (!document.board_form.id.value) {
                alert("아이디를 입력하세요!");
                document.board_form.id.focus();
                return;
            }
            if (!document.board_form.password.value) {
                alert("비밀번호를 입력하세요!");
                document.board_form.password.focus();
                return;
            }
            if (!document.board_form.name.value) {
                alert("이름을 입력하세요!");
                document.board_form.name.focus();
                return;
            }
            if (!document.board_form.subject.value) {
                alert("제목을 입력하세요!");
                document.board_form.subject.focus();
                return;
            }
            if (!document.board_form.content.value) {
                alert("내용을 입력하세요!");
                document.board_form.content.focus();
                return;
            }
            if (!document.board_form.secret_code.value) {
                alert("보안코드를 입력하세요!");
                document.board_form.secret_code.focus();
                return;
            }
            document.board_form.submit();
        }
    </script>
</head>

<body>
    <form name="board_form" method="GET" action="insert_table.php" enctype="multipart/form-data">
        <table style="padding-top:50px" align=center width=auto border=0 cellpadding=2>
            <tr>
                <td style="height:40; float:center; background-color:white">
                    <p style="font-size:25px; text-align:center; color:black; margin-top:15px; margin-bottom:15px">
                        <b>[ 게시글 작성하기 ]</b>
                    </p>
                </td>
            </tr>
            <tr>
                <td bgcolor=white>
                    <form action="board_view.php" method="GET">
                        <table class="table2">
                            <tr>번호</tr>
                            <td><div type="text" name="num" size=15></div></td>
                            <tr>
                                <td>아이디</td>
                                <td><input type="text" name="id" size=15></td>
                            </tr>
                            <tr>
                                <td>비밀번호</td>
                                <td><input type="password" name="password" size=15></td>
                            </tr>
                            <tr>
                                <td>이름</td>
                                <td><input type="text" name="name" size=15></td>
                            </tr>
                            <tr>
                                <td>제목</td>
                                <td><input type="text" name="subject" size=50></td>
                            </tr>
                            <tr>
                                <td>내용</td>
                                <td><textarea name="content" cols=75 rows=15></textarea></td>
                            </tr>
                            <tr>
                                <td>첨부파일</td>
                                <td><input type="file" name="fileup" size=30></td>
                            </tr>
                            <tr>
                                <td><?php echo "보안코드 : $randomNum"?></td>
                                <td><input type="text" name="secret_code" id="secret_code" 
                                    placeholder="보안코드를 입력 해주세요."></td>
                            </tr>
                        </table>
                    </form>
                    <center>
                        <button type="button" onclick="check_input()" location.href="'./board_list.php'">완료</button>
                        <button type="button" onclick="location.href='board_list.php'">목록</button>
                    </center>
                </td>
            </tr>
        </table>
    </form>
</body>

</html>