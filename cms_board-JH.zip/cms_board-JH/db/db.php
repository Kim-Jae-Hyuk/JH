<?php
$hostname = "203.228.23.7";
$username = "naturei20";
$password = "Ni0801!!";
$dbname = "naturei20";
?>
